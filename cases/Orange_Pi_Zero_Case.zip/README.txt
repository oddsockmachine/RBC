                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1918590
Orange Pi Zero Case by farrukh is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Update 23.6.2017
Added a new top part variant (OPIZERO-TOP-USB.stl) which allows you to add an additional USB port via female breakout board. This can be handy for those who are having misery with on-board wifi, So that they can add a cheap $2 dongle such as Ralink mt7601u. Check newly added photos for explanation.

11.26.2016
Got my orange pi zero earlier this week, so decided to make a case for it.
- Removable slots for heatsink and 26-PIN header.
- Antenna hole
- Screw holes are threaded so nuts or tapping is not needed.
- Requires 4x M3*8 screws.
- Recommended layer height 0.2 or less. 100% infill.

# Print Settings

Printer Brand: RepRap
Printer: prusai3
Rafts: No
Supports: No
Resolution: 0.2
Infill: 100